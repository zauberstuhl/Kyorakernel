#!/sbin/sh

/sbin/busybox fdisk /dev/block/avnftl8 < /etc/fdisk.cmd